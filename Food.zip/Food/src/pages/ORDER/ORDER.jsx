import React from 'react'
import './ORDER.css'
const ORDER = () => {
  return (
    <div>ORDER</div>
  )
}

export default ORDER
